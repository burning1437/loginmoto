<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PRACTICE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="path/to/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/styles.css">
  </head>
  <body>

  <div class="container h-100">
    <div class="d-flex justify-content-center h-100">
    <div class="user_card">
        <div class="d-flex justify-content-center">
            <div class="brand_logo_container">
                <img src="img/naruto.png" class="brand_logo" alt="Programming Knowledge logo">

</div>

<div class="d-flex justify-content-center form_container"></div>
<form>
    <div class="input-group-mb-2">
        <div class="input-group-append">
        <span class="input-group-text"><i class="fas fa-user"></i></span>
</div>

<input type="text" name="password"  id="password" class="form-control input_pass" required>
</div>

<div class="input-group-mb-2">
        <div class="input-group-append">
        <span class="input-group-text"><i class="fas fa-key"></i></span>
</div>

<input type="text" name="password"  id="password" class="form-control input_pass" required>
</div>



<div class="form-group">
    <div class="custom-control custom-checkbox">
        <input type="checkbox" name="rememberme" class="custom-control-input" id="customControlInline">
        <label class="custom-control-label" for="customControlInline">Remember me</label>
</div>

</form>
  </div>
</div>

<div class="d-flex justify-content-center mt-3 login-container">
    <button type="button" name="button" id="login"  class="btn login_btn">Login</button>
</div>

<div class="mt-4">
<div class="d-flex justify-content-center links">
    Don't have an account?  <a href="registration.php" class="ml-2">Sign up</a>

</div>



</div>
</div>

<script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>